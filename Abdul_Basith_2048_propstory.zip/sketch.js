//getting NxN grids from the user

var n=window.prompt("Enter the N")

//creating NxN number of arrays

var grid=[];
for(i=0;i<n;i++){
  grid[i]=[];
  for(j=0;j<n;j++){
    grid[i][j]=0;
    }
}

//wheter all grids are occupied

function isgameover(){
  for(let i=0;i<n;i++){
    for(let j=0;j<n;j++){
      if(grid[i][j]===0){
        return false;
      }
    }
  }
  return true;
}

function setup() {
  createCanvas(1200, 1200);
  addnumber();
  addnumber();
}
//add number in a random position in the grid

function addnumber(){
  let options=[];
  for(let i=0;i<n;i++){
    for(let j=0;j<n;j++){
      if(grid[i][j]===0){
        options.push({
          x:i,
          y:j
        });
      }
    }
  }
  if(options.lenght>0);
  let spot=random(options);
  let r=random(1);
  grid[spot.x][spot.y]=r>0.5?2:2;
}

//flip the grid for up arrow model

function flipgrid(){
  for(let i=0;i<n;i++){
    grid[i].reverse();
  }
  return grid;
}

//rotate the grid for right and left arrows model

function rotategrid(grid){
  blankgrid=[];
  for(i=0;i<n;i++){
    blankgrid[i]=[];
    for(j=0;j<n;j++){
      blankgrid[i][j]=0;
    }
  }
  let newgrid=blankgrid;
  for(let i=0;i<n;i++){
    for(let j=0;j<n;j++){
      newgrid[i][j]=grid[j][i];
    }
  }
  return newgrid;
}

//if any key was pressed

function keyPressed(){
  let flipped=false;
  let rotated=false;
  if(keyCode===DOWN_ARROW){
    
  }else if(keyCode===UP_ARROW){
    grid=flipgrid(grid);
    flipped=true;
  }else if(keyCode===RIGHT_ARROW){
    grid=rotategrid(grid);
    rotated=true;
  }else if(keyCode===LEFT_ARROW){
    grid=rotategrid(grid);
    grid=flipgrid(grid);
    rotated=true;
    flipped=true;
  }
  
  for(let i=0;i<n;i++){
    grid[i]=operate(grid[i]);
  }
  if(flipped){
    grid=flipgrid(grid);
  }
  if(rotated){
    grid=rotategrid(grid);
    grid=rotategrid(grid);
    grid=rotategrid(grid);
  }
  addnumber();
  
  //game over if isgameover function is true
  
  let gameover=isgameover();
  if(gameover){
    document.write("GAME OVER")
  }
}
//to slide the array of grid
  function operate(row){
  row=slide(row);
  return row;
}



function draw() {
  background(220);
  drawgrid();
  
}

//to slide the array in one direction

function slide(row){
  let arr=row.filter(val => val);
  let missing=n-arr.length;
  let zeros=Array(missing).fill(0);
  arr=zeros.concat(arr);
  return arr;
}

//to draw the grid and place the value in it

function drawgrid(){
  let w=100;
  for(let i=0;i<n;i++){
    for(let j=0;j<n;j++){
      noFill();
      strokeWeight(2);
      stroke(0);
      rect(i*w,j*w,w,w);
      let val=grid[i][j];
      if(grid[i][j]!==0){
        textAlign(CENTER,CENTER);
        textSize(64);
        fill(0);
        noStroke();
        text(val,i*w+w/2,j*w+w/2);
      }
    }
  }
}